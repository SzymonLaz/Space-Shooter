document.getElementById("startowy_gif").addEventListener("click",zanikanie_start_ladowanie);
document.getElementById("startowy_gif").addEventListener("click",start_gry);

function zanikanie_start_ladowanie()
{
    document.getElementById("startowy_gif").removeEventListener("click", zanikanie_start_ladowanie)
    var przezroczystosc1=1;
    var przezroczystosc2=0;
    document.getElementById("ekran_ladowania").style.opacity=przezroczystosc2;
    document.getElementById("ekran_ladowania").style.display="unset";
    var zanikanie=setInterval(function() {
        if(przezroczystosc1>0)
        {
            przezroczystosc1-=0.05;
            przezroczystosc2+=0.05;
            document.getElementById("startowy_gif").style.opacity=przezroczystosc1;
            document.getElementById("ekran_ladowania").style.opacity=przezroczystosc2;
        }
        else
        {
            document.getElementById("startowy_gif").style.display="none";
            document.getElementById("tlo_poziomow").style.display="none";
            setTimeout(function(){
                zanikanie_start();
            },300)
            clearInterval(zanikanie);
        }
    },40);

};

function zanikanie_start()
{
    document.getElementById("startowy_gif").removeEventListener("click", zanikanie_start)
    var przezroczystosc1=1;
    var przezroczystosc2=0;
    document.getElementById("tlo_poziomow").style.opacity=przezroczystosc2;
    document.getElementById("tlo_poziomow").style.display="unset";
    var zanikanie=setInterval(function() {
        if(przezroczystosc1>0)
        {
            przezroczystosc1-=0.05;
            przezroczystosc2+=0.05;
            document.getElementById("startowy_gif").style.opacity=przezroczystosc1;
            document.getElementById("tlo_poziomow").style.opacity=przezroczystosc2;
        }
        else
        {
            document.getElementById("startowy_gif").style.display="none";
            clearInterval(zanikanie);
        }
    },40);

};

function start_gry()
{
    document.getElementById("startowy_gif").removeEventListener("click", start_gry)
    document.getElementById("tlo_poziomow").removeEventListener("mousemove",ruszanie_statkiem);
    document.getElementById("tlo_poziomow").removeEventListener("click",strzelanie);
    ustaw_przeciwnika("przeciwnik3","meteor.png",5)
        pokaz("przeciwnik3");

        setTimeout(function(){
            silnik_mp3.play();
        },1000)
            

    pokaz("dymek_dialogu");
    pokaz("gif_dialog_rocket");
    pokaz("dymek_tekst");
    pokaz("dymek_guzik_dalej");
    document.getElementById("dymek_tekst").innerHTML="Quill, przypomnisz, jak się kierowało tym złomem, który nazywasz statkiem?";

    document.getElementById("dymek_guzik_dalej").addEventListener("click",dialog2);
    function dialog2()
    {
        document.getElementById("dymek_guzik_dalej").removeEventListener("click",dialog2);
        ukryj("gif_dialog_rocket");
        pokaz("gif_dialog_starlord");
        document.getElementById("dymek_tekst").innerHTML="Podobno jesteś najlepszym szopim pilotem, a nie potrafisz statku prowadzić?";
        document.getElementById("dymek_guzik_dalej").addEventListener("click",dialog3);
    }
    function dialog3()
    {
        document.getElementById("dymek_guzik_dalej").removeEventListener("click",dialog3);
        ukryj("gif_dialog_starlord");
        pokaz("gif_dialog_rocket");
        document.getElementById("dymek_tekst").innerHTML="Potrafię, sprawdzam, czy ty potrafisz. A poza tym nie nazywaj mnie SZOPEM, ty ludzki balasie!";
        document.getElementById("dymek_guzik_dalej").addEventListener("click",dialog4);
    }
    function dialog4()
    {
        document.getElementById("dymek_guzik_dalej").removeEventListener("click",dialog4);
        ukryj("gif_dialog_rocket");
        pokaz("gif_dialog_starlord");
        document.getElementById("dymek_tekst").innerHTML="Niech ci będzie futrzaku. Kierujesz statkiem MYSZKĄ, a strzelasz LEWYM PRZYCISKIEM myszy.";
        document.getElementById("dymek_guzik_dalej").addEventListener("click",dialog5);
    }
    function dialog5()
    {
        document.getElementById("dymek_guzik_dalej").removeEventListener("click",dialog5);
        ukryj("gif_dialog_starlord");
        pokaz("gif_dialog_rocket");
        document.getElementById("dymek_tekst").innerHTML="I widzisz, było tak od razu. Zestrzelę tę skałę przed nami, bo widzę, że nikt inny tyłka nie ruszy.";
        document.getElementById("dymek_guzik_dalej").addEventListener("click",dialog6);
    }
    function dialog6()
    {
        document.getElementById("dymek_guzik_dalej").removeEventListener("click",dialog6);
        ukryj("gif_dialog_rocket");
        ukryj("dymek_dialogu");
        ukryj("dymek_tekst");
        ukryj("dymek_guzik_dalej");

        setTimeout(function(){
            document.getElementById("tlo_poziomow").addEventListener("mousemove",ruszanie_statkiem);
            document.getElementById("tlo_poziomow").addEventListener("click",strzelanie);
        },30)

        czy_skonczone=setInterval(function(){
            if(document.getElementById("przeciwnik3").style.display=="none")
            {
            document.getElementById("tlo_poziomow").removeEventListener("mousemove",ruszanie_statkiem);
            document.getElementById("tlo_poziomow").removeEventListener("click",strzelanie);
                clearInterval(czy_skonczone);
                statek_odlot();

            }
            },200)
        
    }
}


