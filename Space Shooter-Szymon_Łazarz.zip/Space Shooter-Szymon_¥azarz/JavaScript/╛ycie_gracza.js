var gracz={
    zycie: 1,
    poziom: 1,
    obecny_poziom: 1,
}

var zaliczone_poziomy={
    lvl1: "nie",
    lvl2: "nie",
    lvl3: "nie",
    lvl4: "nie",
    lvl5: "nie",
    lvl6: "nie",
    lvl7: "nie",
    lvl8: "nie",
}

function sprawdzaj_zycie()
{
    sprawdz_serca=setInterval(function(){
        if(gracz.zycie==3)
        {
            pokaz("serce1");
            pokaz("serce2");
            pokaz("serce3");
        }
        else if(gracz.zycie==2)
        {
            pokaz("serce1");
            pokaz("serce2");
            ukryj("serce3");
        }
        else if(gracz.zycie==1)
        {
            pokaz("serce1");
            ukryj("serce2");
            ukryj("serce3");
        }
        else
        {
            ukryj("serce1");
            ukryj("serce2");
            ukryj("serce3");
        }
    },100)
}
