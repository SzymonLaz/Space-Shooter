function koniec()
{
    document.getElementById("tlo_poziomow").removeEventListener("mousemove",ruszanie_statkiem);
    document.getElementById("tlo_poziomow").removeEventListener("click",strzelanie);
    var statek_Y=document.getElementById("statek").offsetTop;
    var odlot_koniec=setInterval(function(){
        if(document.getElementById("statek").offsetTop<5)
        {
            clearInterval(odlot_koniec)
            ukryj("statek");
        }
        else
        {
        statek_Y-=10;
        document.getElementById("statek").style.top=statek_Y+"px";
        }
    },20)

    setInterval(function(){
            ukryj("pasek_bossa");
            ukryj("serce3");
            ukryj("serce2");
            ukryj("serce1");
            document.getElementById("okno_koniec").style.opacity="0.85";
            document.getElementById("okno_koniec").style.display="";
            napisy_muzyka.play();
    },400)

    silnik_mp3.pause();
    
    
            for(var i=0;i<100;i++)
            {
            if(typeof(przesuwanie)!="undefined") clearInterval(przesuwanie);
            if(typeof(przesun)!="undefined") clearInterval(przesun);
            if(typeof( lecenie_serc)!="undefined") clearInterval( lecenie_serc);
            if(typeof(sprawdz_serca)!="undefined") clearInterval(sprawdz_serca);
            if(typeof(spawnowanie_serc)!="undefined") clearInterval(spawnowanie_serc);
            if(typeof(kontrola_bossa)!="undefined") clearInterval(kontrola_bossa);
            if(typeof(ruszanie_bossa)!="undefined") clearInterval(ruszanie_bossa);
            if(typeof(sprawdzanie_zycia_bossa)!="undefined") clearInterval(sprawdzanie_zycia_bossa);
            }
}

