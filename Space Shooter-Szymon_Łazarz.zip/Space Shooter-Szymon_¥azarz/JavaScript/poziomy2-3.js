function poziom2()
{
    wlaczanie_poziomu();
    ukryj("serce1");
    ukryj("serce2");
    ukryj("serce3");
    pokaz("statek");
    pojaw_przeciwnika("przeciwnik1","wrogi_statek2.png",10);
    pojaw_przeciwnika("przeciwnik2","wrogi_statek2.png",10);
    pojaw_przeciwnika("przeciwnik3","wrogi_statek2.png",10);
    pojaw_przeciwnika("przeciwnik4","wrogi_statek2.png",10);
    pojaw_przeciwnika("przeciwnik5","wrogi_statek2.png",10);
    gracz.obecny_poziom=2;
    gracz.zycie=3;

    pokaz("dymek_dialogu");
    pokaz("gif_dialog_starlord");
    pokaz("dymek_tekst");
    pokaz("dymek_guzik_dalej");
    document.getElementById("dymek_tekst").innerHTML="Rocket mógłbyś jakoś wzmocnić pancerz naszego statku, żeby nie wybuchał po jednym strzale?";

    document.getElementById("dymek_guzik_dalej").addEventListener("click",lv2_dialog2);
}
    function lv2_dialog2()
    {
        document.getElementById("dymek_guzik_dalej").removeEventListener("click",lv2_dialog2);
        ukryj("gif_dialog_starlord");
        pokaz("gif_dialog_rocket");
        document.getElementById("dymek_tekst").innerHTML="Może i bym mógł, ale czy mi się?";
        document.getElementById("dymek_guzik_dalej").addEventListener("click",lv2_dialog3);
    }
    function lv2_dialog3()
    {
        document.getElementById("dymek_guzik_dalej").removeEventListener("click",lv2_dialog3);
        ukryj("gif_dialog_rocket");
        pokaz("gif_dialog_gamora");
        document.getElementById("dymek_tekst").innerHTML="Jak to, czy ci się chcę!? Przypominam, że to przez ciebie musimy się strzelać z Suwerennymi!";
        document.getElementById("dymek_guzik_dalej").addEventListener("click",lv2_dialog4);
    }
    function lv2_dialog4()
    {
        document.getElementById("dymek_guzik_dalej").removeEventListener("click",lv2_dialog4);
        ukryj("gif_dialog_gamora");
        pokaz("gif_dialog_groot");
        document.getElementById("dymek_tekst").innerHTML="Ja jestem Groot.";
        document.getElementById("dymek_guzik_dalej").addEventListener("click",lv2_dialog5);
    }
    function lv2_dialog5()
    {
        document.getElementById("dymek_guzik_dalej").removeEventListener("click",lv2_dialog5);
        ukryj("gif_dialog_groot");
        pokaz("gif_dialog_gamora");
        document.getElementById("dymek_tekst").innerHTML="Nie próbuj go bronić Groot, siedzimy w tym bagnie przez tego szczura!";
        document.getElementById("dymek_guzik_dalej").addEventListener("click",lv2_dialog6);
    }
    function lv2_dialog6()
    {
        document.getElementById("dymek_guzik_dalej").removeEventListener("click",lv2_dialog6);
        ukryj("gif_dialog_gamora");
        pokaz("gif_dialog_rocket");
        document.getElementById("dymek_tekst").innerHTML="Ech, nie wam będzie. Już to zrobię...";
        document.getElementById("dymek_guzik_dalej").addEventListener("click",lv2_dialog7);
    }
    function lv2_dialog7()
    {
        document.getElementById("dymek_guzik_dalej").removeEventListener("click",lv2_dialog7);
        ukryj("gif_dialog_rocket");
        pokaz("gif_dialog_rocket");
        document.getElementById("dymek_tekst").innerHTML="Dobra, teraz statek wytrzyma 3 uderzenia, zadowoleni? A teraz rozstrzelajmy tych błaznów!";
        document.getElementById("dymek_guzik_dalej").addEventListener("click",lv2_dialog8);
    }
    function lv2_dialog8()
    {
        gracz.zycie=3;
        gracz.obecny_poziom=2;
        
        document.getElementById("dymek_guzik_dalej").removeEventListener("click",lv2_dialog8);
        
        ukryj("dymek_dialogu");
        ukryj("gif_dialog_rocket");
        ukryj("dymek_tekst");
        ukryj("dymek_guzik_dalej");
        lvl2_muzyka.play();
        rozpoczecie_poziomu();

        strzelanie_wroga("przeciwnik1",25);
        strzelanie_wroga("przeciwnik1",30);
        strzelanie_wroga("przeciwnik2",25);
        strzelanie_wroga("przeciwnik2",30);
        strzelanie_wroga("przeciwnik3",25);
        strzelanie_wroga("przeciwnik3",30);
        strzelanie_wroga("przeciwnik4",25);
        strzelanie_wroga("przeciwnik4",30);
        strzelanie_wroga("przeciwnik5",25);
        strzelanie_wroga("przeciwnik5",30);

        var lvl2_czy_dalej=0;

        lvl2_czy_zabici=setInterval(function(){
        if(lvl2_czy_dalej<=3)
        {
            if(document.getElementById("przeciwnik1").style.display=="none" &&
                document.getElementById("przeciwnik2").style.display=="none" &&
                document.getElementById("przeciwnik3").style.display=="none" &&
                document.getElementById("przeciwnik4").style.display=="none" &&
                document.getElementById("przeciwnik5").style.display=="none")
            {
                lvl2_czy_dalej++;
                if(lvl2_czy_dalej<=3)
                setTimeout(function(){
                generuj_wroga("przeciwnik1");
                generuj_wroga("przeciwnik2");
                generuj_wroga("przeciwnik3");
                generuj_wroga("przeciwnik4");
                generuj_wroga("przeciwnik5");
                },500)

            }
        }
        else
        {
            clearInterval(lvl2_czy_zabici);

            if(zaliczone_poziomy.lvl2=="nie")
                {
                gracz.poziom=3;
                }
                zaliczone_poziomy.lvl2="tak";
                statek_odlot();
                setTimeout(function(){
                    lvl2_muzyka.pause();
                },100)

        }
        
        },600);
        
    }

    function poziom3()
    {
        wlaczanie_poziomu();
        pokaz("statek");
        pojaw_przeciwnika("przeciwnik1","wrogi_statek3.png",7);
        pojaw_przeciwnika("przeciwnik2","wrogi_statek3.png",7);
        pojaw_przeciwnika("przeciwnik3","wrogi_statek3.png",7);
        pojaw_przeciwnika("przeciwnik4","wrogi_statek3.png",7);
        pojaw_przeciwnika("przeciwnik5","wrogi_statek3.png",7);
        gracz.obecny_poziom=3;
        gracz.zycie=3;
    
        pokaz("dymek_dialogu");
        pokaz("gif_dialog_starlord");
        pokaz("dymek_tekst");
        pokaz("dymek_guzik_dalej");
        document.getElementById("dymek_tekst").innerHTML="Rocket, pancerz wytrzymuje więcej, ale nigdzie nie widzę, ile strzałów mogę jescze przyjąć.";
    
        document.getElementById("dymek_guzik_dalej").addEventListener("click",lv3_dialog2);
    }
        function lv3_dialog2()
        {
            document.getElementById("dymek_guzik_dalej").removeEventListener("click",lv3_dialog2);
            ukryj("gif_dialog_starlord");
            pokaz("gif_dialog_rocket");
            document.getElementById("dymek_tekst").innerHTML="No nigdy wam nie dogodzi, ale niech wam będzie...";
            document.getElementById("dymek_guzik_dalej").addEventListener("click",lv3_dialog3);
        }
        function lv3_dialog3()
        {
            document.getElementById("dymek_guzik_dalej").removeEventListener("click",lv3_dialog3);
            ukryj("gif_dialog_rocket");
            pokaz("gif_dialog_rocket");
            gracz.zycie=3;
            sprawdzaj_zycie();
            document.getElementById("dymek_tekst").innerHTML="Dobra, od teraz w lewym dolnym rogu macie pokazane, ile uderzeń jeszcze wytrzymamy.";
            document.getElementById("dymek_guzik_dalej").addEventListener("click",lv3_dialog4);
        }
        function lv3_dialog4()
        {
            document.getElementById("dymek_guzik_dalej").removeEventListener("click",lv3_dialog4);
            ukryj("gif_dialog_rocket");
            pokaz("gif_dialog_groot");
            document.getElementById("dymek_tekst").innerHTML="Ja jestem Groot.";
            document.getElementById("dymek_guzik_dalej").addEventListener("click",lv3_dialog5);
        }
        function lv3_dialog5()
        {
            document.getElementById("dymek_guzik_dalej").removeEventListener("click",lv3_dialog5);
            ukryj("gif_dialog_groot");
            pokaz("gif_dialog_rocket");
            document.getElementById("dymek_tekst").innerHTML="Tak Groot, każde serce to jedno uderzenie, które wytrzymamy.";
            document.getElementById("dymek_guzik_dalej").addEventListener("click",lv3_dialog6);
        }
        function lv3_dialog6()
        {
            document.getElementById("dymek_guzik_dalej").removeEventListener("click",lv3_dialog6);
            ukryj("gif_dialog_rocket");
            pokaz("gif_dialog_drax");
            document.getElementById("dymek_tekst").innerHTML="Zamknijcie już te jadaczki, pozbądźmy się tych niegodnych naszej uwagi przeciwników!";
            document.getElementById("dymek_guzik_dalej").addEventListener("click",lv3_dialog7);
        }
 
        function lv3_dialog7()
        {
            gracz.zycie=3;
            gracz.obecny_poziom=3;
            
            document.getElementById("dymek_guzik_dalej").removeEventListener("click",lv3_dialog7);
            
            ukryj("dymek_dialogu");
            ukryj("gif_dialog_drax");
            ukryj("dymek_tekst");
            ukryj("dymek_guzik_dalej");
            lvl3_muzyka.play();
            rozpoczecie_poziomu();
            poruszanie_wroga("przeciwnik1");
            poruszanie_wroga("przeciwnik2");
            poruszanie_wroga("przeciwnik3");
            poruszanie_wroga("przeciwnik4");
            poruszanie_wroga("przeciwnik5");
    
            strzelanie_wroga("przeciwnik1",20);
            strzelanie_wroga("przeciwnik2",20);
            strzelanie_wroga("przeciwnik3",20);
            strzelanie_wroga("przeciwnik4",20);
            strzelanie_wroga("przeciwnik5",20);
    
            var lvl3_czy_dalej=0;
    
            lvl3_czy_zabici=setInterval(function(){
            if(lvl3_czy_dalej<=4)
            {
                if(document.getElementById("przeciwnik1").style.display=="none" &&
                    document.getElementById("przeciwnik2").style.display=="none" &&
                    document.getElementById("przeciwnik3").style.display=="none" &&
                    document.getElementById("przeciwnik4").style.display=="none" &&
                    document.getElementById("przeciwnik5").style.display=="none")
                {
                    lvl3_czy_dalej++;
                    if(lvl3_czy_dalej<=4)
                    setTimeout(function(){
                    generuj_wroga("przeciwnik1");
                    generuj_wroga("przeciwnik2");
                    generuj_wroga("przeciwnik3");
                    generuj_wroga("przeciwnik4");
                    generuj_wroga("przeciwnik5");
                    },500)
    
                }
            }
            else
            {
                clearInterval(lvl3_czy_zabici);
    
                if(zaliczone_poziomy.lvl3=="nie")
                    {
                    gracz.poziom=4;
                    }
                    zaliczone_poziomy.lvl3="tak";
                    statek_odlot();
                    setTimeout(function(){
                        lvl3_muzyka.pause();
                    },100)
    
            }
            
            },600);
            
        }