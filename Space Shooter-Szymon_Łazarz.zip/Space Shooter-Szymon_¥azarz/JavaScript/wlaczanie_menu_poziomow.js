function wlacz_ekran_ladowania()
{
    silnik_mp3.pause();
    var przezroczystosc1=1;
    var przezroczystosc2=0;
    document.getElementById("ekran_ladowania").style.opacity=przezroczystosc2;
    document.getElementById("ekran_ladowania").style.display="";
    var zanikanie=setInterval(function() {
        if(przezroczystosc1>0)
        {
            przezroczystosc1-=0.05;
            przezroczystosc2+=0.05;
            document.getElementById("tlo_poziomow").style.opacity=przezroczystosc1;
            document.getElementById("ekran_ladowania").style.opacity=przezroczystosc2;
            
        }
        else
        {
            document.getElementById("tlo_poziomow").style.display="none";
            setTimeout(function(){
                wlacz_menu_poziomow();
            },300)
            clearInterval(zanikanie);
        }
    },40);

};


function wlacz_menu_poziomow()
{
    sprawdz_ktore_poziomy();
    var przezroczystosc1=1;
    var przezroczystosc2=0;
    document.getElementById("menu_poziomow").style.opacity=przezroczystosc2;
    document.getElementById("menu_poziomow").style.display="";
    
    setTimeout(function(){
        startowa_mp4.play();
    },80)
    var zanikanie=setInterval(function() {
        if(przezroczystosc1>0)
        {
            przezroczystosc1-=0.05;
            przezroczystosc2+=0.05;
            document.getElementById("ekran_ladowania").style.opacity=przezroczystosc1;
            document.getElementById("menu_poziomow").style.opacity=przezroczystosc2;
            
        }
        else
        {
            document.getElementById("ekran_ladowania").style.display="none";
            clearInterval(zanikanie);
        }
    },40);

};

function sprawdz_ktore_poziomy()
{
    if(gracz.poziom >= 1)
    {
        document.getElementById("lv1").style.display="";
        document.getElementById("lock1").style.display="none";
        document.getElementById("tekst_lvl1").addEventListener("click",poziom1);
    }
    if(gracz.poziom >= 2)
    {
        document.getElementById("lv2").style.display="";
        document.getElementById("lock2").style.display="none";
        document.getElementById("tekst_lvl2").addEventListener("click",poziom2);
    }
    if(gracz.poziom >= 3)
    {
        document.getElementById("lv3").style.display="";
        document.getElementById("lock3").style.display="none";
        document.getElementById("tekst_lvl3").addEventListener("click",poziom3);
    }
    if(gracz.poziom >= 4)
    {
        document.getElementById("lv4").style.display="";
        document.getElementById("lock4").style.display="none";
        document.getElementById("tekst_lvl4").addEventListener("click",poziom4);
    }
    if(gracz.poziom >= 5)
    {
        document.getElementById("lv5").style.display="";
        document.getElementById("lock5").style.display="none";
        document.getElementById("tekst_lvl5").addEventListener("click",poziom5);
    }if(gracz.poziom >= 6)
    {
        document.getElementById("lv6").style.display="";
        document.getElementById("lock6").style.display="none";
        document.getElementById("tekst_lvl6").addEventListener("click",poziom6);
    }
    if(gracz.poziom >= 7)
    {
        document.getElementById("lv7").style.display="";
        document.getElementById("lock7").style.display="none";
        document.getElementById("tekst_lvl7").addEventListener("click",poziom7);
    }if(gracz.poziom >= 8)
    {
        document.getElementById("lv8").style.display="";
        document.getElementById("lock8").style.display="none";
        document.getElementById("tekst_lvl8").addEventListener("click",poziom8);
    }
}

function rozpoczecie_poziomu()
{
    setTimeout(function(){
        document.getElementById("tlo_poziomow").addEventListener("mousemove",ruszanie_statkiem);
        document.getElementById("tlo_poziomow").addEventListener("click",strzelanie);
    },30)
}