    function poziom8()
    {
        wlaczanie_poziomu();
        pokaz("statek");
        pojaw_przeciwnika("boss","wrogi_statek_bossa.gif",200);
  
        pojaw_przeciwnika("przeciwnik2","wrogi_statek1.png",5);
 
        pojaw_przeciwnika("przeciwnik4","wrogi_statek1.png",5);
    

        //boss
        gracz.obecny_poziom=8;
        gracz.zycie=3;
        sprawdzaj_zycie();
    
        pokaz("dymek_dialogu");
        pokaz("gif_dialog_starlord");
        pokaz("dymek_tekst");
        pokaz("dymek_guzik_dalej");
        document.getElementById("dymek_tekst").innerHTML="No dobra, jest on troszkę większy niż pozostałe statki.";
    
        document.getElementById("dymek_guzik_dalej").addEventListener("click",lv8_dialog2);
    }
        function lv8_dialog2()
        {
            document.getElementById("dymek_guzik_dalej").removeEventListener("click",lv8_dialog2);
            ukryj("gif_dialog_starlord");
            pokaz("gif_dialog_rocket");
            document.getElementById("dymek_tekst").innerHTML="I co z tego? Nie takich się w życiu rozwalało!";
            document.getElementById("dymek_guzik_dalej").addEventListener("click",lv8_dialog3);
        }
        function lv8_dialog3()
        {
            document.getElementById("dymek_guzik_dalej").removeEventListener("click",lv8_dialog3);
            ukryj("gif_dialog_rocket");
            pokaz("gif_dialog_gamora");
            document.getElementById("dymek_tekst").innerHTML="Nie lekceważ przeciwnika Rocket, widziałam jak nie jeden wojownik przez to ginął...";
            document.getElementById("dymek_guzik_dalej").addEventListener("click",lv8_dialog4);
        }
        function lv8_dialog4()
        {
            document.getElementById("dymek_guzik_dalej").removeEventListener("click",lv8_dialog4);
            ukryj("gif_dialog_gamora");
            pokaz("gif_dialog_starlord");
            document.getElementById("dymek_tekst").innerHTML="Gamora ma rację, musimy się skupić. Nie możemy dać się ponieść emocjom.";
            document.getElementById("dymek_guzik_dalej").addEventListener("click",lv8_dialog5);
        }
        function lv8_dialog5()
        {
            document.getElementById("dymek_guzik_dalej").removeEventListener("click",lv8_dialog5);
            ukryj("gif_dialog_starlord");
            pokaz("gif_dialog_drax");
            document.getElementById("dymek_tekst").innerHTML="Dobrze prawisz, Peterze Quillu. Pokonamy go razem, przyjaciele.";
            document.getElementById("dymek_guzik_dalej").addEventListener("click",lv8_dialog6);
        }
        function lv8_dialog6()
        {
            document.getElementById("dymek_guzik_dalej").removeEventListener("click",lv8_dialog6);
            ukryj("gif_dialog_drax");
            pokaz("gif_dialog_groot");
            document.getElementById("dymek_tekst").innerHTML="Ja jestem Groot.";
            document.getElementById("dymek_guzik_dalej").addEventListener("click",lv8_dialog7);
        }
        function lv8_dialog7()
        {
            document.getElementById("dymek_guzik_dalej").removeEventListener("click",lv8_dialog7);
            ukryj("gif_dialog_groot");
            pokaz("gif_dialog_rocket");
            document.getElementById("dymek_tekst").innerHTML="My ciebie też Groot. To zaczynajmy imprezę!";
            document.getElementById("dymek_guzik_dalej").addEventListener("click",lv8_dialog8);
        }
        
        function lv8_dialog8()
        {
            pokaz("pasek_bossa");
            boss_zycie();
            
            var pokonany_boss="nie";
            gracz.zycie=3;
            gracz.obecny_poziom=8;
            
            document.getElementById("dymek_guzik_dalej").removeEventListener("click",lv8_dialog8);
            
            ukryj("dymek_dialogu");
            ukryj("gif_dialog_rocket");
            ukryj("dymek_tekst");
            ukryj("dymek_guzik_dalej");
            lvl8_muzyka.play();
            rozpoczecie_poziomu();
    

            strzelanie_wroga("przeciwnik2",40);

            strzelanie_wroga("przeciwnik4",40);


            strzelanie_wroga("boss",70);
            strzelanie_wroga("boss",63);
            strzelanie_wroga("boss",56);

            ruszanie_bossa=setInterval(function(){
                    o_ile_bossa=parseInt(Math.random()*600);
                    if(o_ile_bossa>10 && o_ile_bossa<500)
                    {
                        $("#boss").animate({left:o_ile_bossa+"px"},1700);
                    }
                    kontrola_bossa=setInterval(function(){
                    if(document.getElementById("boss").style.display=="none")
                    {
                        clearInterval(kontrola_bossa);
                        clearInterval(ruszanie_bossa);
                    }
            
                },50)

            },1800)
            

            spawn_serc();
    
            var lvl8_czy_dalej=0;
    
            lvl8_czy_zabici=setInterval(function(){
            if(lvl8_czy_dalej<=30 && pokonany_boss=="nie")
            {
                if(document.getElementById("przeciwnik2").style.display=="none")
                {
                    lvl8_czy_dalej++;
                    if(lvl8_czy_dalej<=30)
                    setTimeout(function(){
                    pojaw_przeciwnika_animacja("przeciwnik2","wrogi_statek1.png",5);
                    setTimeout(function(){strzelanie_wroga("przeciwnik2",40);},200)
                    },500)
                }
                if(document.getElementById("przeciwnik4").style.display=="none")
                {
                    lvl8_czy_dalej++;
                    if(lvl8_czy_dalej<=30)
                    setTimeout(function(){
                    pojaw_przeciwnika_animacja("przeciwnik4","wrogi_statek1.png",5);
                    setTimeout(function(){strzelanie_wroga("przeciwnik4",40);},200)
                    },500)
                }

            }
            else
            {
                clearInterval(lvl8_czy_zabici);
            }},600);

            czy_pokonany_boss=setInterval(function(){
                if(document.getElementById("boss").style.display!="none")
                {
                    
                }
                else
                {   pokonany_boss="tak";
                    if(document.getElementById("przeciwnik2").style.display=="none" &&
                        document.getElementById("przeciwnik4").style.display=="none" &&
                        document.getElementById("boss").alt<=0)
                        {
                            koniec();
                            lvl8_muzyka.pause();
                            clearInterval(czy_pokonany_boss);
                            
                        }
                    
                }

            },800)
               
            
            
        }

    
function boss_zycie()
{
    sprawdzanie_zycia_bossa=setInterval(function(){
        if(document.getElementById("boss").style.display!="none"){
    var boss_id=document.getElementById("boss");
    var boss_zycie=boss_id.alt;
    document.getElementById("pasek_bossa_kolor").style.width=boss_zycie+"px";
    if(boss_zycie>120)
    {
        document.getElementById("pasek_bossa_kolor").style.backgroundColor="green";
    }
    else if(boss_zycie>50)
    {
        document.getElementById("pasek_bossa_kolor").style.backgroundColor="yellow";
    }
    else
    {
        document.getElementById("pasek_bossa_kolor").style.backgroundColor="red";
    }

}
    else
    {
        clearInterval(sprawdzanie_zycia_bossa);
    }
    },50)
}

