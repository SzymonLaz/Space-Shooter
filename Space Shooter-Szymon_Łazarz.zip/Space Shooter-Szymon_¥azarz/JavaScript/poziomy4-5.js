function poziom4()
{
    wlaczanie_poziomu();
    pokaz("statek");
    pojaw_przeciwnika("przeciwnik1","wrogi_statek3.png",7);
    pojaw_przeciwnika("przeciwnik2","wrogi_statek2.png",10);
    pojaw_przeciwnika("przeciwnik3","wrogi_statek1.png",5);
    pojaw_przeciwnika("przeciwnik4","wrogi_statek2.png",10);
    pojaw_przeciwnika("przeciwnik5","wrogi_statek3.png",7);
    gracz.obecny_poziom=4;
    gracz.zycie=3;
    sprawdzaj_zycie();

    pokaz("dymek_dialogu");
    pokaz("gif_dialog_starlord");
    pokaz("dymek_tekst");
    pokaz("dymek_guzik_dalej");
    document.getElementById("dymek_tekst").innerHTML="I znowu oni...";

    document.getElementById("dymek_guzik_dalej").addEventListener("click",lv4_dialog2);
}
    function lv4_dialog2()
    {
        document.getElementById("dymek_guzik_dalej").removeEventListener("click",lv4_dialog2);
        ukryj("gif_dialog_starlord");
        pokaz("gif_dialog_rocket");
        document.getElementById("dymek_tekst").innerHTML="Nie narzekaj Quill, przynajmniej nam się nie nudzi.";
        document.getElementById("dymek_guzik_dalej").addEventListener("click",lv4_dialog3);
    }
    function lv4_dialog3()
    {
        document.getElementById("dymek_guzik_dalej").removeEventListener("click",lv4_dialog3);
        ukryj("gif_dialog_rocket");
        pokaz("gif_dialog_starlord");
        document.getElementById("dymek_tekst").innerHTML="Taa, świetne zajęcie Rocket, masz rację.";
        document.getElementById("dymek_guzik_dalej").addEventListener("click",lv4_dialog4);
    }
    function lv4_dialog4()
    {
        document.getElementById("dymek_guzik_dalej").removeEventListener("click",lv4_dialog4);
        ukryj("gif_dialog_starlord");
        pokaz("gif_dialog_rocket");
        document.getElementById("dymek_tekst").innerHTML="Tak z innej beczki, to ulepszyłem radar i jak będziesz widzieć nadlatujące serca to je zbierz.";
        document.getElementById("dymek_guzik_dalej").addEventListener("click",lv4_dialog5);
    }
    function lv4_dialog5()
    {
        document.getElementById("dymek_guzik_dalej").removeEventListener("click",lv4_dialog5);
        ukryj("gif_dialog_rocket");
        pokaz("gif_dialog_drax");
        document.getElementById("dymek_tekst").innerHTML="Dlaczego Suwerenni mieliby rzucać w nas sercami?";
        document.getElementById("dymek_guzik_dalej").addEventListener("click",lv4_dialog6);
    }
    function lv4_dialog6()
    {
        document.getElementById("dymek_guzik_dalej").removeEventListener("click",lv4_dialog6);
        ukryj("gif_dialog_drax");
        pokaz("gif_dialog_rocket");
        document.getElementById("dymek_tekst").innerHTML="Nie będą rzucać w nas sercami, po prostu oznaczyłem części naprawcze jako serca...";
        document.getElementById("dymek_guzik_dalej").addEventListener("click",lv4_dialog7);
    }
    function lv4_dialog7()
    {
        document.getElementById("dymek_guzik_dalej").removeEventListener("click",lv4_dialog7);
        ukryj("gif_dialog_rocket");
        pokaz("gif_dialog_rocket");
        document.getElementById("dymek_tekst").innerHTML="Jeśli je zbierzemy to będą delikatnie naprawiać pancerz, jeśli jest uszkodzony.";
        document.getElementById("dymek_guzik_dalej").addEventListener("click",lv4_dialog8);
    }
    function lv4_dialog8()
    {
        document.getElementById("dymek_guzik_dalej").removeEventListener("click",lv4_dialog8);
        ukryj("gif_dialog_rocket");
        pokaz("gif_dialog_groot");
        document.getElementById("dymek_tekst").innerHTML="Ja jestem Groot.";
        document.getElementById("dymek_guzik_dalej").addEventListener("click",lv4_dialog9);
    }
    function lv4_dialog9()
    {
        document.getElementById("dymek_guzik_dalej").removeEventListener("click",lv4_dialog9);
        ukryj("gif_dialog_groot");
        pokaz("gif_dialog_rocket");
        document.getElementById("dymek_tekst").innerHTML="Tak, jeśli będziemy mieć mniej niż 3 serca w lewym dolnym rogu, to zebrane serce odnowi jedno.";
        document.getElementById("dymek_guzik_dalej").addEventListener("click",lv4_dialog10);
    }
    function lv4_dialog10()
    {
        gracz.zycie=3;
        gracz.obecny_poziom=4;
        
        document.getElementById("dymek_guzik_dalej").removeEventListener("click",lv4_dialog10);
        
        ukryj("dymek_dialogu");
        ukryj("gif_dialog_rocket");
        ukryj("dymek_tekst");
        ukryj("dymek_guzik_dalej");
        lvl4_muzyka.play();
        rozpoczecie_poziomu();

        strzelanie_wroga("przeciwnik1",20);

        strzelanie_wroga("przeciwnik2",25);
        strzelanie_wroga("przeciwnik2",30);

        strzelanie_wroga("przeciwnik3",40);

        strzelanie_wroga("przeciwnik4",25);
        strzelanie_wroga("przeciwnik4",30);

        strzelanie_wroga("przeciwnik5",20);
        spawn_serc();

        var lvl4_czy_dalej=0;

        lvl4_czy_zabici=setInterval(function(){
        if(lvl4_czy_dalej<=4)
        {
            if(document.getElementById("przeciwnik1").style.display=="none" &&
                document.getElementById("przeciwnik2").style.display=="none" &&
                document.getElementById("przeciwnik3").style.display=="none" &&
                document.getElementById("przeciwnik4").style.display=="none" &&
                document.getElementById("przeciwnik5").style.display=="none")
            {
                lvl4_czy_dalej++;
                if(lvl4_czy_dalej<=4)
                setTimeout(function(){
                generuj_wroga("przeciwnik1");
                generuj_wroga("przeciwnik2");
                generuj_wroga("przeciwnik3");
                generuj_wroga("przeciwnik4");
                generuj_wroga("przeciwnik5");
                },500)

            }
        }
        else
        {
            clearInterval(lvl4_czy_zabici);

            if(zaliczone_poziomy.lvl4=="nie")
                {
                gracz.poziom=5;
                }
                zaliczone_poziomy.lvl4="tak";
                statek_odlot();
                setTimeout(function(){
                    lvl4_muzyka.pause();
                },100)

        }
        
        },600);
        
    }

    function poziom5()
    {
        wlaczanie_poziomu();
        pokaz("statek");
        pojaw_przeciwnika("przeciwnik1","wrogi_statek1.png",5);
        pojaw_przeciwnika("przeciwnik2","wrogi_statek1.png",5);
        pojaw_przeciwnika("przeciwnik3","wrogi_statek1.png",5);
        pojaw_przeciwnika("przeciwnik4","wrogi_statek1.png",5);
        pojaw_przeciwnika("przeciwnik5","wrogi_statek1.png",5);
        gracz.obecny_poziom=5;
        gracz.zycie=3;
        sprawdzaj_zycie();
    
        pokaz("dymek_dialogu");
        pokaz("gif_dialog_groot");
        pokaz("dymek_tekst");
        pokaz("dymek_guzik_dalej");
        document.getElementById("dymek_tekst").innerHTML="Ja jestem Groot.";
    
        document.getElementById("dymek_guzik_dalej").addEventListener("click",lv5_dialog2);
    }
        function lv5_dialog2()
        {
            document.getElementById("dymek_guzik_dalej").removeEventListener("click",lv5_dialog2);
            ukryj("gif_dialog_groot");
            pokaz("gif_dialog_gamora");
            document.getElementById("dymek_tekst").innerHTML="Niestety, ale tak, znowu nas atakują... To już się nudne robi...";
            document.getElementById("dymek_guzik_dalej").addEventListener("click",lv5_dialog3);
        }
        function lv5_dialog3()
        {
            document.getElementById("dymek_guzik_dalej").removeEventListener("click",lv5_dialog3);
            ukryj("gif_dialog_gamora");
            pokaz("gif_dialog_drax");
            document.getElementById("dymek_tekst").innerHTML="Peterze Quillu, czy nie ma jakiejś metody, żeby to wkońcu zakończyć raz na zawsze?";
            document.getElementById("dymek_guzik_dalej").addEventListener("click",lv5_dialog4);
        }
        function lv5_dialog4()
        {
            document.getElementById("dymek_guzik_dalej").removeEventListener("click",lv5_dialog4);
            ukryj("gif_dialog_drax");
            pokaz("gif_dialog_starlord");
            document.getElementById("dymek_tekst").innerHTML="Nooo... może by odpuścili, jakby zniszczyć ich statek głównodowodzący z Królową.";
            document.getElementById("dymek_guzik_dalej").addEventListener("click",lv5_dialog5);
        }
        function lv5_dialog5()
        {
            document.getElementById("dymek_guzik_dalej").removeEventListener("click",lv5_dialog5);
            ukryj("gif_dialog_starlord");
            pokaz("gif_dialog_gamora");
            document.getElementById("dymek_tekst").innerHTML="No to, na co czekamy. Prowadź do tej Królowej Złotych Ludków.";
            document.getElementById("dymek_guzik_dalej").addEventListener("click",lv5_dialog6);
        }
        function lv5_dialog6()
        {
            document.getElementById("dymek_guzik_dalej").removeEventListener("click",lv5_dialog6);
            ukryj("gif_dialog_gamora");
            pokaz("gif_dialog_starlord");
            document.getElementById("dymek_tekst").innerHTML="Spróbuję ją namierzyć, ale zajmie to dłuższą chwilę.";
            document.getElementById("dymek_guzik_dalej").addEventListener("click",lv5_dialog7);
        }
        function lv5_dialog7()
        {
            document.getElementById("dymek_guzik_dalej").removeEventListener("click",lv5_dialog7);
            ukryj("gif_dialog_starlord");
            pokaz("gif_dialog_rocket");
            document.getElementById("dymek_tekst").innerHTML="To ty szukaj, a ja zestrzele tych przed nami!";
            document.getElementById("dymek_guzik_dalej").addEventListener("click",lv5_dialog8);
        }
        
        function lv5_dialog8()
        {
            gracz.zycie=3;
            gracz.obecny_poziom=5;
            
            document.getElementById("dymek_guzik_dalej").removeEventListener("click",lv5_dialog8);
            
            ukryj("dymek_dialogu");
            ukryj("gif_dialog_rocket");
            ukryj("dymek_tekst");
            ukryj("dymek_guzik_dalej");
            lvl5_muzyka.play();
            rozpoczecie_poziomu();
    
            strzelanie_wroga("przeciwnik1",40);
            strzelanie_wroga("przeciwnik2",40);
            strzelanie_wroga("przeciwnik3",40);
            strzelanie_wroga("przeciwnik4",40);
            strzelanie_wroga("przeciwnik5",40);
            spawn_serc();
    
            var lvl5_czy_dalej=0;
    
            lvl5_czy_zabici=setInterval(function(){
            if(lvl5_czy_dalej<=4)
            {
                if(document.getElementById("przeciwnik1").style.display=="none" &&
                    document.getElementById("przeciwnik2").style.display=="none" &&
                    document.getElementById("przeciwnik3").style.display=="none" &&
                    document.getElementById("przeciwnik4").style.display=="none" &&
                    document.getElementById("przeciwnik5").style.display=="none")
                {
                    lvl5_czy_dalej++;
                    if(lvl5_czy_dalej<=4)
                    setTimeout(function(){
                    generuj_wroga("przeciwnik1");
                    generuj_wroga("przeciwnik2");
                    generuj_wroga("przeciwnik3");
                    generuj_wroga("przeciwnik4");
                    generuj_wroga("przeciwnik5");
                    },500)
    
                }
            }
            else
            {
                clearInterval(lvl5_czy_zabici);
    
                if(zaliczone_poziomy.lvl5=="nie")
                    {
                    gracz.poziom=6;
                    }
                    zaliczone_poziomy.lvl5="tak";
                    statek_odlot();
                    setTimeout(function(){
                        lvl5_muzyka.pause();
                    },100)
    
            }
            
            },600);
            
        }