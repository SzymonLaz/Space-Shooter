function generuj_wroga(id_przeciwnika)
{
    var los=parseInt(Math.random()*10);
    if(los<2)
    {
        pojaw_przeciwnika_animacja(id_przeciwnika,"wrogi_statek1.png",5);
        setTimeout(function(){
            strzelanie_wroga(id_przeciwnika,40);
        },400)
    }
    else if(los<7)
    {
        pojaw_przeciwnika_animacja(id_przeciwnika,"wrogi_statek2.png",10);
        setTimeout(function(){
            strzelanie_wroga(id_przeciwnika,25);
            strzelanie_wroga(id_przeciwnika,30);
        },400)
    }
    else
    {
        pojaw_przeciwnika_animacja(id_przeciwnika,"wrogi_statek3.png",7);
        setTimeout(function(){
            strzelanie_wroga(id_przeciwnika,20);
            poruszanie_wroga(id_przeciwnika);
        },400)
    }
}

function poruszanie_wroga(id_wroga)
{
    var przesun=setInterval(function(){
        var o_ile=parseInt(Math.random()*100);
        if(o_ile>20 && o_ile<100)
        {
            $("#"+id_wroga).animate({top:o_ile+"px"},190);
            
        }
    },200)
    var przesuwanie=setInterval(function(){
        if(document.getElementById(id_wroga).style.display=="none")
        {
            document.getElementById(id_wroga).style.top="20px";
            clearInterval(przesuwanie);
            clearInterval(przesun)
        }

    },50)
}