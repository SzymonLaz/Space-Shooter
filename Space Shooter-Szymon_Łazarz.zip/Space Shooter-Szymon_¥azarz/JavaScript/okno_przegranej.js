
function przegrana()
{
    document.getElementById("okno_przegranej").style.display="";
    document.getElementById("przeciwnik1").style.display="none";
    document.getElementById("przeciwnik2").style.display="none";
    document.getElementById("przeciwnik3").style.display="none";
    document.getElementById("przeciwnik4").style.display="none";
    document.getElementById("przeciwnik5").style.display="none";
    document.getElementById("boss").style.display="none";
    if(typeof(sprawdz_serca)!="undefined") clearInterval(sprawdz_serca);
    if(typeof(spawnowanie_serc)!="undefined") clearInterval(spawnowanie_serc);

    for(var i=0;i<100;i++)
            {
            if(typeof(przesuwanie)!="undefined") clearInterval(przesuwanie);
            if(typeof(przesun)!="undefined") clearInterval(przesun);
            if(typeof(lecenie_serc)!="undefined") clearInterval( lecenie_serc);
            }
    document.getElementById("przeciwnik1").style.top="20px";
    document.getElementById("przeciwnik2").style.top="20px";
    document.getElementById("przeciwnik3").style.top="20px";
    document.getElementById("przeciwnik4").style.top="20px";
    document.getElementById("przeciwnik5").style.top="20px";
    for(var kolejny=0;kolejny<101;kolejny++)
    {
        if(document.getElementById("kula"+kolejny)!=null) document.getElementById("kula"+kolejny).remove();
    }

    
    reset_statku();
    setTimeout(function(){
        document.getElementById("okno_przegranej").addEventListener('click',powtorka);
    },2000);
    
    switch(gracz.obecny_poziom)
    {
        case 1:
            lvl1_muzyka.pause();
            if(typeof(czy_zabici)!="undefined") clearInterval(czy_zabici);
            if(typeof(czy_zabici2)!="undefined") clearInterval(czy_zabici2);
            if(typeof(czy_zabici3)!="undefined") clearInterval(czy_zabici3);
        break;
        case 2:
            lvl2_muzyka.pause();
            if(typeof(lvl2_czy_zabici)!="undefined") clearInterval(lvl2_czy_zabici);
        break;
        case 3:
            lvl3_muzyka.pause();
            if(typeof(lvl3_czy_zabici)!="undefined") clearInterval(lvl3_czy_zabici);
        break;
        case 4:
            lvl4_muzyka.pause();
            if(typeof(lvl4_czy_zabici)!="undefined") clearInterval(lvl4_czy_zabici);
        break;
        case 5:
            lvl5_muzyka.pause();
            if(typeof(lvl5_czy_zabici)!="undefined") clearInterval(lvl5_czy_zabici);
        break;
        case 6:
            lvl6_muzyka.pause();
            if(typeof(lvl6_czy_zabici)!="undefined") clearInterval(lvl6_czy_zabici);

        break;
        case 7:
            lvl7_muzyka.pause();
            if(typeof(lvl7_czy_zabici)!="undefined") clearInterval(lvl7_czy_zabici);

        break;
        case 8:
            lvl8_muzyka.pause();
            if(typeof(lvl8_czy_zabici)!="undefined") clearInterval(lvl8_czy_zabici);
            if(typeof(kontrola_bossa)!="undefined") clearInterval(kontrola_bossa);
            if(typeof(ruszanie_bossa)!="undefined") clearInterval(ruszanie_bossa);
            if(typeof(sprawdzanie_zycia_bossa)!="undefined") clearInterval(sprawdzanie_zycia_bossa);
        break;
    }
    document.getElementById("przeciwnik1").style.top="20px";
    document.getElementById("przeciwnik2").style.top="20px";
    document.getElementById("przeciwnik3").style.top="20px";
    document.getElementById("przeciwnik4").style.top="20px";
    document.getElementById("przeciwnik5").style.top="20px";
    document.getElementById("boss").style.top="80px";
    document.getElementById("boss").style.left="250px";
}


function powtorka()
{
    document.getElementById("okno_przegranej").removeEventListener('click',powtorka);
    switch(gracz.obecny_poziom)
    {
        case 1:
            lv1_dialog7();
            pokaz("statek");
            pojaw_przeciwnika("przeciwnik1","wrogi_statek1.png",5);
            pojaw_przeciwnika("przeciwnik3","wrogi_statek1.png",5);
            pojaw_przeciwnika("przeciwnik5","wrogi_statek1.png",5);
        break;
        case 2:
            lv2_dialog8();
            pokaz("statek");
            pojaw_przeciwnika("przeciwnik1","wrogi_statek2.png",10);
            pojaw_przeciwnika("przeciwnik2","wrogi_statek2.png",10);
            pojaw_przeciwnika("przeciwnik3","wrogi_statek2.png",10);
            pojaw_przeciwnika("przeciwnik4","wrogi_statek2.png",10);
            pojaw_przeciwnika("przeciwnik5","wrogi_statek2.png",10);
        
        break;
        case 3:
            lv3_dialog7();
            pokaz("statek");
            pojaw_przeciwnika("przeciwnik1","wrogi_statek3.png",7);
            pojaw_przeciwnika("przeciwnik2","wrogi_statek3.png",7);
            pojaw_przeciwnika("przeciwnik3","wrogi_statek3.png",7);
            pojaw_przeciwnika("przeciwnik4","wrogi_statek3.png",7);
            pojaw_przeciwnika("przeciwnik5","wrogi_statek3.png",7);
            sprawdzaj_zycie();

        break;
        case 4:
            lv4_dialog10();
            pokaz("statek");
            pojaw_przeciwnika("przeciwnik1","wrogi_statek3.png",7);
            pojaw_przeciwnika("przeciwnik2","wrogi_statek2.png",10);
            pojaw_przeciwnika("przeciwnik3","wrogi_statek1.png",5);
            pojaw_przeciwnika("przeciwnik4","wrogi_statek2.png",10);
            pojaw_przeciwnika("przeciwnik5","wrogi_statek3.png",7);
            sprawdzaj_zycie();

        break;
        case 5:
            lv5_dialog8();
            pokaz("statek");
            pojaw_przeciwnika("przeciwnik1","wrogi_statek1.png",5);
            pojaw_przeciwnika("przeciwnik2","wrogi_statek1.png",5);
            pojaw_przeciwnika("przeciwnik3","wrogi_statek1.png",5);
            pojaw_przeciwnika("przeciwnik4","wrogi_statek1.png",5);
            pojaw_przeciwnika("przeciwnik5","wrogi_statek1.png",5);
            sprawdzaj_zycie();
        
        break;
        case 6:
            lv6_dialog8();
            pokaz("statek");
            pojaw_przeciwnika("przeciwnik1","wrogi_statek2.png",10);
            pojaw_przeciwnika("przeciwnik2","wrogi_statek1.png",5);
            pojaw_przeciwnika("przeciwnik3","wrogi_statek2.png",10);
            pojaw_przeciwnika("przeciwnik4","wrogi_statek1.png",5);
            pojaw_przeciwnika("przeciwnik5","wrogi_statek2.png",10);
            sprawdzaj_zycie();

        break;
        case 7:
            lv7_dialog8();
            pokaz("statek");
            pojaw_przeciwnika("przeciwnik1","wrogi_statek2.png",10);
            pojaw_przeciwnika("przeciwnik2","wrogi_statek2.png",10);
            pojaw_przeciwnika("przeciwnik3","wrogi_statek2.png",10);
            pojaw_przeciwnika("przeciwnik4","wrogi_statek2.png",10);
            pojaw_przeciwnika("przeciwnik5","wrogi_statek2.png",10);
            sprawdzaj_zycie();

        break;
        case 8:
            document.getElementById("boss").style.top="80px";
            document.getElementById("boss").style.left="250px";
            lv8_dialog8();
            pokaz("statek");
            pojaw_przeciwnika("boss","wrogi_statek_bossa.gif",200);
            pojaw_przeciwnika("przeciwnik2","wrogi_statek1.png",5);
            pojaw_przeciwnika("przeciwnik4","wrogi_statek1.png",5);
            sprawdzaj_zycie();

        break;
    }


    document.getElementById("przeciwnik1").style.top="20px";
    document.getElementById("przeciwnik2").style.top="20px";
    document.getElementById("przeciwnik3").style.top="20px";
    document.getElementById("przeciwnik4").style.top="20px";
    document.getElementById("przeciwnik5").style.top="20px";
    document.getElementById("okno_przegranej").style.display="none";
}